<p align="center">
  <img src="https://raw.githubusercontent.com/An0nUD4Y/SocialFish/master/social.png">  
</p>

<h1 align="center">SocialFish v2.0</h1>
<p align="center">
       NOW MORE ATTACKS ARE AVAILABLE.
  In Ultimate phishing tool with Ngrok integrated
</p>

<p align="center">
 NOW YOU WILL GET LIVE INFORMATION ABOUT YOUR VICTIM'S IP, GEOLOCATION, COUNTRY, ISP, CITY, ATTACKED DATE & TIME, AND MANY MORE.
 
</p>

### PREREQUISITES ( Please verify if you have installed )

* Python 3
* Wget from Python
* PHP
* sudo
## :octocat: DEVELOPERS 
1. usama7628674 
2. An0nUD4Y [ Instagram.com/its_udy ]
3. UNDEADSEC
4. Micrafast 
5. alexmozzhakov
6. _______________________ (Waiting For Your Contribution)

### TESTED ON FOLLOWING
* **Kali Linux - Rolling Edition**

* **Parrot OS - Rolling Edition**

* **Linux Mint - 18.3 Sylvia**

* **Ubuntu - 16.04.3 LTS**

* **MacOS High Sierra**

### CLONE
```
git clone https://github.com/An0nUD4Y/SocialFish.git
```

### RUNNING (In Linux)

```
cd SocialFish
```

```
sudo apt install python3-pip
```

```
sudo pip3 install -r requirements.txt
```

```
chmod 777 SocialFish.py
```

```
python3 SocialFish.py

```
   OR
   
```
./SocialFish.py    

```
### RUNNING (FOR ANDROID USERS IN TERMUX)

```
First install { Termux } from Playstore.

```

```
After opening Follow below commands One by one

```

```
pkg install git python php curl openssh grep

```
```
pip3 install wget

```
```
git clone https://github.com/An0nUD4Y/SocialFish 

```
```
cd SocialFish

```
```
chmod 777 SocialFish.py

```
```
python SocialFish.py

or

./SocialFish.py

```
### Running (One Code installation in termux)


```
First install { Termux } from Playstore.

```

```
After opening Copy and run this Single Command.

```
```
pkg install git python php curl openssh grep && pip3 install wget && git clone https://github.com/An0nUD4Y/SocialFish && cd SocialFish && chmod 777 SocialFish.py && python SocialFish.py

```

## AVAILABLE PAGES

**+ Facebook:**
- Traditional Facebook login page.
- Advanced Poll Method.
- Fake Security login with Facebook Page. 
- Facebook messenger login page.

**+ Google:**
- Traditional Google login page.
- Advanced Poll Method.

**+ LinkedIn:**
- Traditional LinkedIn login page.

**+ Github:**
- Traditional Github login page.

**+ Stackoverflow:**
- Traditional Stackoverflow login page.

**+ Wordpress:**
- Similar Wordpress login page.

**+ Twitter:**
- Traditional Twitter login page.

**+ Instagram:**
- Traditional Instagram login page.
- Instagram Autoliker Phishing Page [ ADVANCED METHOD ADOPTED ].

### WHAT'S NEW FEATURES
**1) LIVE ATTACK**
- Now you will have live information about the victims such as : IP ADDRESS, Geolocation, ISP, Country, & many more.

**2) COMPATIBILITY**
- All the sites are mobile compatible.

### NEW PAGES
<p align="center">
  
**1) FACEBOOK PHISHING:**
- Traditional Facebook login page.
- Advanced Poll Method.
- Fake Security login with Facebook Page. 
- Facebook messenger login page.
        
 **2) INSTAGRAM PHISHING:**
 - Traditional Login Page
 - Fake instagram Autoliker Page [ REDIRECTS TO ORIGINAL AUTOLIKER PAGE AFTER SUBMIT ] 

 **3) SNAPCHAT PHISHING:**
 - Traditional Snapchat Login Page
 
 **4) YAHOO PHISHING:**
 - Traditional Yahoo Login Page
 
 **5) TWITCH PHISHING:**
 - Traditional Twitch Login Page [ Login With  Facebook Also Available ]
 
 **6) MICROSOFT PHISHING:**
 - Traditional Microsoft-Live Web Login Page
 
 **7) STEAM PHISHING:**
 - Traditional Steam Web Login Page
 
 **8) VK PHISHING:**
 - Traditional VK Web Login Page
 - Advanced Poll Method
 
 **9) ICLOUD PHISHING:**
 - Traditional iCloud Web Login Page
</p>



### SCREENSHOT
![Shot](https://github.com/An0nUD4Y/SocialFish/blob/master/sc.png)

![Shot](https://github.com/An0nUD4Y/SocialFish/blob/master/sc1.png)

![Shot](https://github.com/An0nUD4Y/SocialFish/blob/master/sc2.png)


## DISCLAIMER
<p align="center">
  TO BE USED FOR EDUCATIONAL PURPOSES ONLY
</p>

The use of the SocialFish is COMPLETE RESPONSIBILITY of the END-USER. Developers assume NO liability and are NOT responsible for any misuse or damage caused by this program.

"DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
Taken from [LICENSE](LICENSE).




## Help us with Donation
If you liked the work and want to support us all, you can donate :D

<img src="https://github.com/An0nUD4Y/SocialFish/blob/master/donation.png"></img>

Bitcoin Address: qpuwdfv3p3gpufzctjapp0dp9z4kkk9x6cgl2hhghe


### VIDEO DEMO
<p align="center">
<a href="https://www.youtube.com/watch?v=dCuZR2C7Hhw">
  <img src="https://raw.githubusercontent.com/An0nUD4Y/SocialFish/master/video.png" />
</a></p>
